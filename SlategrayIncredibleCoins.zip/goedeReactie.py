import random
#Reactie wanneer je de vraag goed hebt beantwoord
def goedeReactie():
  goedeReactie = ["Wow goed gedaan", "Uitstekend", "Dat is goed", "Heel goed", "Dat is goed", "Wow wat goed", "Dat is juist", "Dat is correct", "Goed gedaan", "Wow je bent een topper", "Ga zo door!"]
  return random.choice(goedeReactie)